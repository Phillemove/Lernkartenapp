# Lernkartenapp
Solution für Hausarbeit
